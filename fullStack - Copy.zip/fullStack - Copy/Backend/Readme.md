[.gitignore generator](https://mrkandreev.name/snippets/gitignore-generator/)

"type": "module",

npm i -D nodemon

.env node version

npm i -D prettier

create a cluster at mongodb either shell or atlas
problem with passwor having special symbol 

npm i  express mongoose

npm i cookie-parser cors