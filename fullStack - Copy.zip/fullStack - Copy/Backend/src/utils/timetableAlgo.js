 const timetableGenerator=async (workingdays,classes,teacherID)=>{
    const timetable= [1,2,3]
    const teachID =teacherID
    return {teachID,timetable}
}

export default timetableGenerator