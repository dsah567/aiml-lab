import React from 'react'
import { Link } from 'react-router-dom'

function Home() {
    // window.location.reload();
    return (
        <>
        <h1>Home</h1>
        </>
    )
}

export default Home
