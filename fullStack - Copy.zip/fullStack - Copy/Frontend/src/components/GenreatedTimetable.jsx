import React from 'react'

function GenreatedTimetable() {
    return (
        <>Genreated Timetable</>
    )
}

export default GenreatedTimetable
