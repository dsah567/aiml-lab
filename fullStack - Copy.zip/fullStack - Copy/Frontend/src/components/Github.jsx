import React from 'react'

function Github() {
    return (
        <>Github</>
    )
}

export default Github
