import React from 'react'

function Profile() {
    return (
        <>profile</>
    )
}

export default Profile
